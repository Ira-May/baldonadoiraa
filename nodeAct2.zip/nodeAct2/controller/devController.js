const web ={
    app:(req, res)=>{
        res.render('home');
    },
    //about:(req, res)=>{
        //res.render('about');
    //},
    //contact:(req, res)=>{
        //res.render('contact');
    //},
    //email:(req, res)=>{
        //res.render('email');
    //},
    //login:(req, res)=>{
        //res.render('login');
    //}

};
module.exports = web;